/** @param {NS} ns */
export async function main(ns) {

	let pathWay = [];
	let allServers = [];
	let serversList = ns.scan("home");
	let nextServers = [];
	let boughtservers = ns.getPurchasedServers();
	let target = ns.args[0];
	let origin = ns.getHostname();
	let parents = [];
	let pair = [];

	while (serversList.length > 0) {
		let server = serversList.pop();

		if (!allServers.includes(server) && !boughtservers.includes(server)) {

			allServers.push(server);
			nextServers = ns.scan(server);

			for (var i = 0; i < nextServers.length; i++) {

				if (!allServers.includes(nextServers[i])) {
					serversList.push(nextServers[i]);
				}
				if (nextServers[i] != origin) {
					pair = [nextServers[i], server];
					parents.push(pair);
				}
			}
		}
	}

i = target;
while (i != ns.getHostname()) {
    pathWay.push(i);
    ns.tprint("Re-creating path at " + i);
    //Search through the parentTracker array to find this nodes parent
    for (let j = 0; j < parents.length; ++j) {
        pair = parents[j];
        if (pair[0] == i) {
            i = pair[1];
            break;
        }
    }
}

pathWay.reverse();
ns.tprint(pathWay);

}