/** @param {NS} ns */
export async function main(ns) {

	let allServers = [];
	let serversList = ns.scan("home");
	let nextServers = [];
	let boughtservers = ns.getPurchasedServers();
	let serversToBackdoor = [];
	//GETTING ALL THE SERVERS
	while (serversList.length > 0) {

		let server = serversList.pop();
		if (!allServers.includes(server) && !boughtservers.includes(server)) {
			allServers.push(server);
			nextServers = ns.scan(server);
			for (var i = 0; i < nextServers.length; i++) {
				if (!allServers.includes(nextServers[i])) {
					serversList.push(nextServers[i]);
				}
			}
		}
	}

	for (let serverName of allServers) {
		if (ns.getServerRequiredHackingLevel(serverName) <= ns.getHackingLevel() && serverName != "home") {

			if (!ns.getServer(serverName).backdoorInstalled) {
				serversToBackdoor.push(serverName);
			}
		}
		await ns.sleep(10);
	}
	ns.tprint(serversToBackdoor);
}