/** @param {NS} ns */
export async function main(ns) {
	let sleepTime = ns.getWeakenTime("joesguns");
	while (true) {

		await ns.weaken("joesguns");

	}
}