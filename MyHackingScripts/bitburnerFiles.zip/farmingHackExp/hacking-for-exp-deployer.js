/** @param {NS} ns */
export async function main(ns) {

	let allServers = [];
	let serversList = ns.scan("home");
	let nextServers = [];

	let serverHackName = ns.args[0];

	if (serverHackName == null) {
		serverHackName = "joesguns";
	}


	//GETTING ALL THE SERVERS
	while (serversList.length > 0) {

		let server = serversList.pop();
		if (!allServers.includes(server)) {
			allServers.push(server);
			nextServers = ns.scan(server);
			for (var i = 0; i < nextServers.length; i++) {
				if (!allServers.includes(nextServers[i])) {
					serversList.push(nextServers[i]);
				}
			}
		}
	}

	for (let serverName of allServers) {
		if (ns.hasRootAccess(serverName)) {
			await ns.scp("/farmingHackExp/weaken-server.js", serverName);
			ns.killall(serverName);
			let ramAvailable = ns.getServerMaxRam(serverName) - ns.getServerUsedRam(serverName);
			let ramPerThread = ns.getScriptRam("/farmingHackExp/weaken-server.js");

			let threads = Math.floor(ramAvailable / ramPerThread);
			if (threads === 0) {
				ns.exec("/farmingHackExp/weaken-server.js", serverName, 1);

			} else {
				ns.exec("/farmingHackExp/weaken-server.js", serverName, threads);
			}
			ns.tprint("==========================");
			ns.tprint("For xp gain now " + serverName);
			ns.tprint("==========================");
		}
		await ns.sleep(500);
	}

}