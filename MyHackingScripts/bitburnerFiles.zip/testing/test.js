/** @param {NS} ns */
export async function main(ns) {
	ns.tprint(Math.pow(2, 10));
}