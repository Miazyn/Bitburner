/** @param {NS} ns */
export async function main(ns) {

	ns.tprint("Current Money: " + ns.getServerMoneyAvailable("joesguns"));
	ns.tprint(ns.getServerMaxMoney("joesguns") * 0.85);
	ns.tprint("Current Security: " + ns.getServerSecurityLevel("joesguns"));
	ns.tprint(ns.getServerMinSecurityLevel("joesguns") + 5);


}