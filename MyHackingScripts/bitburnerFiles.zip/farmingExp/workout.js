/** @param {NS} ns */
export async function main(ns) {

	let Player = ns.getPlayer();
	let agilityLvl = Player.skills.agility;
	let strengthLvl = Player.skills.strength;
	let defenseLvl = Player.skills.defense;
	let dexterityLvl = Player.skills.dexterity;

	let gym = "powerhouse gym";

	while (agilityLvl < 200 || strengthLvl < 200 || defenseLvl < 200 || dexterityLvl < 200) {
		if (agilityLvl < 200) {
			ns.tprint("Training Agility");
			ns.gymWorkout(gym, 'Agility', true);
			await ns.sleep(600000);
			ns.stopAction();
		}
		else if (strengthLvl < 200) {
			ns.tprint("Training Strength");
			ns.gymWorkout(gym, 'Strength', true);
			await ns.sleep(600000);
			ns.stopAction();
		}
		else if (defenseLvl < 200) {
			ns.tprint("Training Defense");
			ns.gymWorkout(gym, 'Defense', true);
			await ns.sleep(600000);
			ns.stopAction();
		}
		else if (dexterityLvl < 200) {
			ns.tprint("Training Dexterity");
			ns.gymWorkout(gym, 'Dexterity', true);
			await ns.sleep(600000);
			ns.stopAction();
		}
		Player = ns.getPlayer();
		agilityLvl = Player.skills.agility;
		strengthLvl = Player.skills.strength;
		defenseLvl = Player.skills.defense;
		dexterityLvl = Player.skills.dexterity;

	}


}