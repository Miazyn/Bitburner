/** @param {NS} ns */
export async function main(ns) {

	let target = ns.args[0];
	let boughtservers = ns.getPurchasedServers();

	

	for (let serverName of boughtservers) {
		await ns.scp("weakenTarget.js", serverName);
		if (ns.hasRootAccess(serverName)) {
			if (serverName == "home") {

				ns.kill("early-hack-template.js joesguns", serverName);
			}
			else {
				ns.tprint("------------" + "------------");
				ns.tprint("Has root access on " + serverName + "!!!");
				ns.killall(serverName);
				ns.tprint("Killed all scripts running");
			}
		}
		
		let ramAvailable = ns.getServerMaxRam(serverName) - ns.getServerUsedRam(serverName);
		let ramPerThread = ns.getScriptRam("weakenTarget.js");

		let threads = Math.floor(ramAvailable / ramPerThread);

		if (ns.hasRootAccess(serverName)) {
			ns.tprint("------------" + "------------");
			ns.tprint("Gained root access on " + serverName + "!!!");
			if (threads === 0) {
				ns.tprint("------------" + "------------");
				ns.tprint("Executing script with 1 thread..");
				ns.exec("weakenTarget.js", serverName, 1, target);
			} else {
				ns.tprint("------------" + "------------");
				ns.tprint("Executing script with " + threads + " threads...");
				ns.exec("weakenTarget.js", serverName, threads, target);
			}

		}
		ns.tprint("==========================" + "==========================");
		ns.tprint("Waiting...");
		await ns.sleep(500);

		ns.tprint("Finished with " + boughtservers.length);
		ns.tprint("Time to weaken server.");
	}
}