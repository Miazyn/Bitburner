/** @param {NS} ns */
export async function main(ns) {

	ns.exec("killSwitch.js", "home", 1, "joesguns");
	ns.exec("purchase-server-Argsgb.js", "home", 1, Math.pow(2, 10));
}