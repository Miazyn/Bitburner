/** @param {NS} ns */
export async function main(ns) {

	let allServers = [];
	let serversList = ns.scan("home");
	let nextServers = [];
	let boughtServers = ns.getPurchasedServers();
	let serverBought = false;
	//GETTING ALL THE SERVERS
	while (serversList.length > 0) {

		let server = serversList.pop();
		if (!allServers.includes(server)) {
			allServers.push(server);
			nextServers = ns.scan(server);
			for (var i = 0; i < nextServers.length; i++) {
				if (!allServers.includes(nextServers[i])) {
					serversList.push(nextServers[i]);
				}
			}
		}
	}

	for (let serverName of allServers) {
		if (ns.getServerMoneyAvailable(serverName) == 0 && ns.getServerMaxMoney(serverName) == 0) {
			for(let bought of boughtServers){
				if(serverName == bought){
						serverBought = true;
				}
			}
			if(serverBought == false){
			ns.tprint("No money on this server: " + serverName);
			ns.tprint("MaxMoney: " + ns.getServerMaxMoney(serverName));
			ns.tprint("CurMoney: " + ns.getServerMoneyAvailable(serverName));
			ns.tprint("=======================");
			}else{
				serverBought = false;
			}
		}
		await ns.sleep(10);
	}
}