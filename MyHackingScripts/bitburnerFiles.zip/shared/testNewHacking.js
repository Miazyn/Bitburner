/** @param {NS} ns */
export async function main(ns) {

	var target = ns.args[0];
	if (target == null) {
		target = 'n00dles';
	}
	let moneyThresh = ns.getServerMaxMoney(target) * 0.75;
	let securityThresh = ns.getServerMinSecurityLevel(target) + 5;

	let sleepTime = 2000;
	while (true) {
		if (ns.getServerSecurityLevel(target) > securityThresh) {
			sleepTime = ns.getWeakenTime(target);
			ns.exec("shared/weaken.js", "home", 1, 'n00dles');
			ns.tprint("Weakened " + target);
		} else if (ns.getServerMoneyAvailable(target) < moneyThresh) {
			sleepTime = ns.getGrowTime(target);
			ns.exec("shared/grow.js", "home", 1, 'n00dles');
			ns.tprint("Grew " + target);
		} else {
			sleepTime = ns.getHackTime(target);
			ns.exec("shared/hack.js", "home", 1, 'n00dles');
			ns.tprint("Hacked " + target);
		}
		ns.tprint("Waiting...");

		await ns.sleep(sleepTime + 500);

	}

}