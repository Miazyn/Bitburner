/** @param {NS} ns */
export async function main(ns) {

	var ram = Math.pow(2, 3);

	var i = 0;

	while (i < ns.getPurchasedServerLimit()) {

		if (ns.getServerMoneyAvailable("home") > ns.getPurchasedServerCost(ram) * 1.5) {
			var hostname = ns.purchaseServer("pserv-" + i, ram);
			await ns.scp("early-hack-template.js", hostname);
			ns.exec("early-hack-template.js", hostname, 3, "joesguns");
			i++;

		}
		await ns.sleep(60000);

	}
	ns.alert("Purchased all servers");

	ns.exit();

}